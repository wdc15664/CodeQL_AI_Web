from .util import VERSION as __version__
